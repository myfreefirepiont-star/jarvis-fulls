# 📱 راهنمای جامع بیلد و نصب برنامه J.A.R.V.I.S روی گوشی موبایل

این راهنما مراحل گام‌به‌گام تولید خروجی فایل **APK (نسخه Debug و Release)** و نحوه انتقال و نصب آن روی گوشی اندرویدی شما را توضیح می‌دهد.

---

## ۱. تفاوت نسخه Debug و Release

- **نسخه Debug (`app-debug.apk`)**: 
  - هم‌اکنون به صورت خودکار بیلد شده و دارای امضای تستی امنیتی است.
  - می‌توانید بلافاصله آن را روی هر گوشی اندرویدی نصب و تست کنید (سریع‌ترین راه).
  - مسیر فایل: `app/build/outputs/apk/debug/app-debug.apk`

- **نسخه Release (`app-release.apk`)**: 
  - نسخه نهایی، بهینه‌سازی‌شده برای انتشار و با حجم کمتر و سرعت بالاتر.
  - نیاز به فایل کلید امضا (`my-upload-key.jks`) دارد که اسکریپت آماده‌شده آن را خودکار می‌سازد.
  - مسیر فایل: `app/build/outputs/apk/release/app-release.apk`

---

## ۲. روش اجرای اسکریپت بیلد خودکار

در ریشه پروژه، دو اسکریپت آماده قرار داده شده است:

### در لینوکس / مک (Linux / macOS):
ترمینال را در پوشه پروژه باز کنید و دستورات زیر را اجرا نمایید:
```bash
chmod +x build_release.sh
./build_release.sh
```

### در ویندوز (Windows):
کافیست فایل `build_release.bat` را دو بار کلیک کنید، یا در CMD دستور زیر را بنویسید:
```cmd
build_release.bat
```

---

## ۳. اجرای دستی با دستورات خط فرمان (Manual Build)

اگر می‌خواهید خودتان بدون اسکریپت دستورات را اجرا کنید:

### گام اول: ساخت فایل کلید Keystore
```bash
keytool -genkey -v -keystore my-upload-key.jks \
    -alias upload \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -storepass jarvis123456 -keypass jarvis123456 \
    -dname "CN=JARVIS, OU=AI, O=Stark, L=Tehran, ST=Tehran, C=IR"
```

### گام دوم: تنظیم متغیرهای رمز و مسیر
- در لینوکس/مک:
```bash
export KEYSTORE_PATH="$(pwd)/my-upload-key.jks"
export STORE_PASSWORD="jarvis123456"
export KEY_PASSWORD="jarvis123456"
```
- در ویندوز (CMD):
```cmd
set KEYSTORE_PATH=%cd%\my-upload-key.jks
set STORE_PASSWORD=jarvis123456
set KEY_PASSWORD=jarvis123456
```

### گام سوم: ساخت خروجی APK
```bash
gradle :app:assembleRelease
```

---

## ۴. نحوه انتقال و نصب فایل APK روی گوشی موبایل

پس از تولید فایل APK، یکی از روش‌های زیر را برای نصب انتخاب کنید:

1. **انتقال با کابل USB یا پیام‌رسان (ساده‌ترین روش):**
   - فایل `app-debug.apk` یا `app-release.apk` را از طریق کابل USB، تلگرام (Saved Messages)، واتساپ یا Google Drive به گوشی خود بفرستید.
   - در گوشی، روی فایل لمس کرده و گزینه **Install** را بزنید.
   - *نکته:* در صورت نمایش پیام *Install Unknown Apps*، دسترسی به مدیر فایل یا تلگرام را تایید کنید.

2. **نصب مستقیم از طریق کابل با دستور ADB:**
   اگر گوشی با کابل متصل و حالت *USB Debugging* روشن است:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```

---

## ۵. تنظیم دسترسی‌های اولیه در اولین اجرای برنامه روی گوشی

برای بهره‌مندی از امکانات کامل J.A.R.V.I.S:
1. **مجوز میکروفون**: هنگام باز شدن برنامه، اجازه ضبط صدا را بدهید تا جارویس بتواند صدای شما را بشنود.
2. **مجوز نمایش روی سایر برنامه‌ها (Display over other apps)**: برای فعال‌سازی دکمه شناور هولوگرافیک آرک‌ری‌اکتور روی بازی‌ها و برنامه‌ها.
3. **روشن کردن شنود پس‌زمینه**: در صفحه اصلی یا تنظیمات، کلید **«شنود دائمی خارج برنامه»** را فعال کنید تا هر زمان گفتید **«جارویس»** پاسخ دهد: **«بله قربان!»**.
