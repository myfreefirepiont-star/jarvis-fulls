package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.example.ai.JarvisBrain
import com.example.data.JarvisDatabase
import com.example.manager.AppManager
import com.example.manager.DeviceManager
import com.example.speech.JarvisSpeechManager

class JarvisApp : Application() {

    lateinit var database: JarvisDatabase
        private set
    lateinit var speechManager: JarvisSpeechManager
        private set
    lateinit var deviceManager: DeviceManager
        private set
    lateinit var appManager: AppManager
        private set
    lateinit var brain: JarvisBrain
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = JarvisDatabase.getDatabase(this)
        speechManager = JarvisSpeechManager(this)
        deviceManager = DeviceManager(this)
        appManager = AppManager(this)
        brain = JarvisBrain(this, database, deviceManager, appManager, speechManager)

        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                VOICE_CHANNEL_ID,
                "J.A.R.V.I.S Voice Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "سرویس فعال J.A.R.V.I.S برای گوش به زنگ بودن و شنود فرمان‌های صوتی"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    companion object {
        const val VOICE_CHANNEL_ID = "jarvis_voice_service_channel"
        lateinit var instance: JarvisApp
            private set
    }
}
