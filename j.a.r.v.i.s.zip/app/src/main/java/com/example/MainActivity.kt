package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.screens.*
import com.example.ui.theme.*
import kotlinx.coroutines.flow.collectLatest

enum class JarvisScreen(val title: String, val icon: ImageVector) {
    DASHBOARD("داشبورد", Icons.Default.Dashboard),
    CHAT("گفتگو", Icons.Default.Forum),
    APPS_GAMES("برنامه‌ها", Icons.Default.SportsEsports),
    VISION("بینایی", Icons.Default.CameraAlt),
    TOOLS("ابزارها", Icons.Default.Build),
    EMERGENCY("اضطراری", Icons.Default.Warning),
    MEMORY("حافظه", Icons.Default.Psychology),
    SETTINGS("تنظیمات", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainContent()
            }
        }
    }

    @Composable
    private fun MainContent() {
        var currentScreen by remember { mutableStateOf(JarvisScreen.DASHBOARD) }
        val app = JarvisApp.instance
        val brain = app.brain

        // Request initial permissions on launch
        val permissionsLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.RequestMultiplePermissions()
        ) { _ -> }

        LaunchedEffect(Unit) {
            val neededPermissions = mutableListOf<String>()
            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                neededPermissions.add(Manifest.permission.RECORD_AUDIO)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                neededPermissions.add(Manifest.permission.POST_NOTIFICATIONS)
            }
            if (neededPermissions.isNotEmpty()) {
                permissionsLauncher.launch(neededPermissions.toTypedArray())
            }
        }

        // Listen to navigation events from voice/brain
        LaunchedEffect(Unit) {
            brain.navigationEvents.collectLatest { event ->
                when (event) {
                    "EMERGENCY", "FAKECALL" -> currentScreen = JarvisScreen.EMERGENCY
                    "VISION" -> currentScreen = JarvisScreen.VISION
                    "APPS" -> currentScreen = JarvisScreen.APPS_GAMES
                }
            }
        }

        // BackHandler
        if (currentScreen != JarvisScreen.DASHBOARD) {
            BackHandler {
                currentScreen = JarvisScreen.DASHBOARD
            }
        }

        Scaffold(
            containerColor = ObsidianBackground,
            contentWindowInsets = WindowInsets.systemBars,
            bottomBar = {
                NavigationBar(
                    containerColor = DarkNavySurfaceElevated,
                    tonalElevation = 8.dp,
                    modifier = Modifier.testTag("bottom_nav_bar")
                ) {
                    val primaryScreens = listOf(
                        JarvisScreen.DASHBOARD,
                        JarvisScreen.CHAT,
                        JarvisScreen.APPS_GAMES,
                        JarvisScreen.VISION,
                        JarvisScreen.TOOLS,
                        JarvisScreen.EMERGENCY,
                        JarvisScreen.SETTINGS
                    )

                    primaryScreens.forEach { screen ->
                        val selected = currentScreen == screen
                        NavigationBarItem(
                            selected = selected,
                            onClick = { currentScreen = screen },
                            icon = {
                                Icon(
                                    imageVector = screen.icon,
                                    contentDescription = screen.title,
                                    tint = if (selected) {
                                        if (screen == JarvisScreen.EMERGENCY) DangerRed else NeonCyan
                                    } else TextMuted
                                )
                            },
                            label = {
                                Text(
                                    text = screen.title,
                                    fontSize = 10.sp,
                                    color = if (selected) Color.White else TextMuted
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = (if (screen == JarvisScreen.EMERGENCY) DangerRed else NeonCyan).copy(alpha = 0.2f)
                            ),
                            modifier = Modifier.testTag("nav_item_${screen.name.lowercase()}")
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                Crossfade(targetState = currentScreen, label = "screen_crossfade") { screen ->
                    when (screen) {
                        JarvisScreen.DASHBOARD -> DashboardScreen(
                            onNavigateToChat = { currentScreen = JarvisScreen.CHAT },
                            onNavigateToApps = { currentScreen = JarvisScreen.APPS_GAMES },
                            onNavigateToVision = { currentScreen = JarvisScreen.VISION },
                            onNavigateToEmergency = { currentScreen = JarvisScreen.EMERGENCY },
                            onNavigateToTools = { currentScreen = JarvisScreen.TOOLS }
                        )
                        JarvisScreen.CHAT -> ChatScreen()
                        JarvisScreen.APPS_GAMES -> AppsGamesScreen()
                        JarvisScreen.VISION -> SmartCameraScreen(
                            onSendToChat = { resultText ->
                                brain.processUserQuery(resultText, isVoice = false)
                                currentScreen = JarvisScreen.CHAT
                            }
                        )
                        JarvisScreen.TOOLS -> DailyToolsScreen()
                        JarvisScreen.EMERGENCY -> EmergencyScreen()
                        JarvisScreen.MEMORY -> MemoryScreen()
                        JarvisScreen.SETTINGS -> SettingsScreen()
                    }
                }
            }
        }
    }
}
