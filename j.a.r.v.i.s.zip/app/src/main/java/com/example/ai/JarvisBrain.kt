package com.example.ai

import android.content.Context
import com.example.data.FinancialRecord
import com.example.data.JarvisDatabase
import com.example.data.MemoryItem
import com.example.data.NoteItem
import com.example.data.TodoItem
import com.example.manager.AppManager
import com.example.manager.DeviceManager
import com.example.speech.JarvisSpeechManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: String, // "user" or "jarvis"
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val actionExecuted: String? = null
)

class JarvisBrain(
    private val context: Context,
    private val database: JarvisDatabase,
    private val deviceManager: DeviceManager,
    private val appManager: AppManager,
    private val speechManager: JarvisSpeechManager
) {
    private val scope = CoroutineScope(Dispatchers.Main)
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val _messages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                sender = "jarvis",
                text = "سلام قربان. سیستم‌های J.A.R.V.I.S آنلاین هستند. آماده دریافت فرمان‌های شما هستم."
            )
        )
    )
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _activeMode = MutableStateFlow("استاندارد") // استاندارد, گیمینگ, رانندگی, خواب, اضطراری
    val activeMode: StateFlow<String> = _activeMode.asStateFlow()

    // Trigger events for UI actions (e.g. launch fake call, open camera, etc.)
    private val _navigationEvents = MutableSharedFlow<String>()
    val navigationEvents: SharedFlow<String> = _navigationEvents.asSharedFlow()

    init {
        // Wire wake-word callback from speech manager
        speechManager.onWakeWordDetected = {
            onWakeWordTriggered()
        }
        speechManager.onCommandRecognized = { command ->
            processUserQuery(command, isVoice = true)
        }
    }

    fun onWakeWordTriggered() {
        deviceManager.vibrate(80)
        deviceManager.playJarvisChime()
        speechManager.speak("بله قربان! در خدمتم.")
        addJarvisMessage("بله قربان! در خدمتم. چه کاری می‌توانم برایتان انجام دهم؟")
    }

    fun processUserQuery(query: String, isVoice: Boolean = false) {
        val cleanQuery = query.trim()
        if (cleanQuery.isBlank()) return

        // Add user message to history
        val userMsg = ChatMessage(sender = "user", text = cleanQuery)
        _messages.value = _messages.value + userMsg

        speechManager.setThinking(true)

        scope.launch {
            // First check if matching any local intent / command
            val intentResult = handleLocalIntent(cleanQuery)
            if (intentResult != null) {
                speechManager.setThinking(false)
                addJarvisMessage(intentResult.responseText, intentResult.actionType)
                if (isVoice) {
                    speechManager.speak(intentResult.responseText)
                }
                return@launch
            }

            // If not a system intent, use AI conversational response
            val aiResponse = generateAiResponse(cleanQuery)
            speechManager.setThinking(false)
            addJarvisMessage(aiResponse)
            if (isVoice) {
                speechManager.speak(aiResponse)
            }
        }
    }

    private data class IntentResult(
        val responseText: String,
        val actionType: String? = null
    )

    private suspend fun handleLocalIntent(query: String): IntentResult? {
        val q = query.lowercase()

        // 1. Wake response check
        if (q == "جارویس" || q == "jarvis" || q == "هی جارویس" || q == "الو جارویس") {
            deviceManager.playJarvisChime()
            return IntentResult("بله قربان! در خدمتم.")
        }

        // 2. Flashlight (چراغ قوه)
        if (q.contains("چراغ") || q.contains("flashlight") || q.contains("نور")) {
            val enable = !q.contains("خاموش") && !q.contains("ببند") && !q.contains("off")
            val success = deviceManager.setTorch(enable)
            return if (success) {
                if (enable) IntentResult("چراغ‌قوه روشن شد، قربان.", "TORCH_ON")
                else IntentResult("چراغ‌قوه خاموش شد، قربان.", "TORCH_OFF")
            } else {
                IntentResult("امکان تغییر وضعیت چراغ‌قوه در این لحظه وجود ندارد.")
            }
        }

        // 3. Battery status (باتری / شارژ)
        if (q.contains("باتری") || q.contains("شارژ") || q.contains("battery")) {
            val level = deviceManager.getBatteryLevel()
            val charging = deviceManager.isBatteryCharging()
            val chargingText = if (charging) "و در حال شارژ است." else "و در حال استفاده از باتری هستید."
            return IntentResult("سطح انرژی باتری شما $level درصد است $chargingText", "BATTERY_CHECK")
        }

        // 4. Time & Date (ساعت و تاریخ)
        if (q.contains("ساعت") || q.contains("تاریخ") || q.contains("time") || q.contains("date")) {
            val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            val dateFmt = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date())
            return IntentResult("ساعت فعلی $timeFmt و تاریخ امروز $dateFmt می‌باشد، قربان.", "TIME_CHECK")
        }

        // 5. Open Apps & Games (باز کن / اجرا کن)
        if (q.startsWith("باز کن") || q.startsWith("اجرا کن") || q.startsWith("برو به") || q.startsWith("open ") || q.startsWith("launch ")) {
            val target = q
                .removePrefix("باز کن")
                .removePrefix("اجرا کن")
                .removePrefix("برو به")
                .removePrefix("open")
                .removePrefix("launch")
                .replace("برنامه", "")
                .replace("بازی", "")
                .trim()

            val (launched, msg) = appManager.launchAppByNameOrAlias(target)
            return IntentResult(msg, if (launched) "APP_LAUNCHED" else null)
        }

        // 6. Modes (حالت‌ها)
        if (q.contains("گیمینگ") || q.contains("بازی") || q.contains("gaming mode")) {
            _activeMode.value = "گیمینگ"
            return IntentResult("حالت گیمینگ فعال شد، قربان. منابع پردازشی دستگاه بهینه‌سازی شده و اعلان‌های غیرضروری محدود شدند.", "MODE_GAMING")
        }
        if (q.contains("رانندگی") || q.contains("driving")) {
            _activeMode.value = "رانندگی"
            return IntentResult("حالت رانندگی فعال گردید. پاسخگویی صوتی در حالت حداکثری قرار گرفت تا حواس شما از مسیر پرت نشود.", "MODE_DRIVING")
        }
        if (q.contains("خواب") || q.contains("شب") || q.contains("sleep")) {
            _activeMode.value = "خواب"
            return IntentResult("حالت خواب فعال شد، قربان. نور صفحه کاهش یافت و وضعیت آرامش برقرار است. شب خوش.", "MODE_SLEEP")
        }
        if (q.contains("عادی") || q.contains("استاندارد") || q.contains("normal")) {
            _activeMode.value = "استاندارد"
            return IntentResult("سیستم به حالت استاندارد بازگشت.", "MODE_NORMAL")
        }

        // 7. Emergency & Safety (خطر / اضطراری / تماس ساختگی / آژیر)
        if (q.contains("آژیر") || q.contains("siren")) {
            if (deviceManager.isSirenPlaying()) {
                deviceManager.stopEmergencySiren()
                return IntentResult("آژیر خطر متوقف شد، قربان.", "SIREN_STOPPED")
            } else {
                deviceManager.startEmergencySiren()
                return IntentResult("آژیر هشدار با حداکثر توان به صدا درآمد!", "SIREN_STARTED")
            }
        }
        if (q.contains("تماس ساختگی") || q.contains("fake call") || q.contains("تماس فرار")) {
            _navigationEvents.emit("FAKECALL")
            return IntentResult("تماس ساختگی شبیه‌سازی شده فعال شد، قربان.", "FAKECALL_TRIGGERED")
        }
        if (q.contains("خطر") || q.contains("کمک") || q.contains("اضطراری") || q.contains("sos") || q.contains("emergency")) {
            _activeMode.value = "اضطراری"
            _navigationEvents.emit("EMERGENCY")
            return IntentResult("پروتکل اضطراری J.A.R.V.I.S فعال شد. اطلاعات نجات و موقعیت مکانی شما در دسترس است.", "EMERGENCY_TRIGGERED")
        }

        // 8. Notes & Todos (یادداشت / وظیفه / کار جدید)
        if (q.startsWith("یادداشت") || q.startsWith("بنویس") || q.startsWith("note ")) {
            val content = q
                .removePrefix("یادداشت")
                .removePrefix("بنویس")
                .removePrefix("note")
                .trim()
            if (content.isNotBlank()) {
                withContext(Dispatchers.IO) {
                    database.jarvisDao().insertNote(
                        NoteItem(
                            title = "یادداشت صوتی",
                            content = content
                        )
                    )
                }
                return IntentResult("یادداشت شما با موفقیت ذخیره شد: '$content'", "NOTE_SAVED")
            }
        }

        if (q.startsWith("کار جدید") || q.startsWith("وظیفه") || q.startsWith("یادآوری") || q.startsWith("todo ")) {
            val title = q
                .removePrefix("کار جدید")
                .removePrefix("وظیفه")
                .removePrefix("یادآوری")
                .removePrefix("todo")
                .trim()
            if (title.isNotBlank()) {
                withContext(Dispatchers.IO) {
                    database.jarvisDao().insertTodo(
                        TodoItem(
                            title = title,
                            priority = "بالا"
                        )
                    )
                }
                return IntentResult("وظیفه جدید '$title' به فهرست برنامه‌های روزانه شما افزوده شد.", "TODO_SAVED")
            }
        }

        // 9. Memory Store & Recall (یادت باشه / به خاطر بسپار)
        if (q.startsWith("یادت باشه") || q.startsWith("به خاطر بسپار") || q.startsWith("remember ")) {
            val mem = q
                .removePrefix("یادت باشه")
                .removePrefix("به خاطر بسپار")
                .removePrefix("remember")
                .trim()
            if (mem.isNotBlank()) {
                withContext(Dispatchers.IO) {
                    database.jarvisDao().insertMemory(
                        MemoryItem(
                            title = "دانش کاربر",
                            content = mem,
                            category = "preference"
                        )
                    )
                }
                return IntentResult("اطلاعات '$mem' در هسته حافظه بلندمدت من ذخیره شد، قربان.", "MEMORY_STORED")
            }
        }

        // 10. Financial Record (خرج کردم / درآمد)
        if (q.contains("هزینه") || q.contains("خرج کردم") || q.contains("تومان")) {
            val numbers = Regex("\\d+").findAll(q).map { it.value.toLong() }.toList()
            if (numbers.isNotEmpty()) {
                val amount = numbers.first()
                withContext(Dispatchers.IO) {
                    database.jarvisDao().insertFinancial(
                        FinancialRecord(
                            title = "ثبت سریع هزینه",
                            amount = amount,
                            isExpense = true,
                            category = "عمومی"
                        )
                    )
                }
                return IntentResult("مبلغ $amount تومان در سیستم مالی به عنوان هزینه ثبت گردید، قربان.", "FINANCIAL_SAVED")
            }
        }

        return null
    }

    private suspend fun generateAiResponse(prompt: String): String = withContext(Dispatchers.IO) {
        // Build Jarvis persona system prompt
        val systemPrompt = "شما J.A.R.V.I.S هستید، یک هوش مصنوعی بسیار پیشرفته، مودب، هوشمند، وفادار و دقیق الهام گرفته از جارویس مرد آهنی. به کاربر احترام می‌گذارید و او را 'قربان' خطاب می‌کنید. پاسخ‌هایتان باید دقیق، جذاب، متین و به زبان فارسی روان یا انگلیسی (بسته به زبان کاربر) باشد. بیش از حد طولانی پاسخ ندهید مگر نیاز باشد."

        // Attempt Gemini API call via standard endpoint if apiKey is available in BuildConfig or environment
        val apiKey = try {
            val buildConfigClass = Class.forName("com.jarvis.ai.BuildConfig")
            val field = buildConfigClass.getField("GEMINI_API_KEY")
            field.get(null) as? String ?: ""
        } catch (_: Exception) {
            ""
        }

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$apiKey"
                val jsonBody = JSONObject().apply {
                    put("contents", JSONArray().apply {
                        put(JSONObject().apply {
                            put("role", "user")
                            put("parts", JSONArray().apply {
                                put(JSONObject().put("text", "$systemPrompt\n\nدرخواست کاربر: $prompt"))
                            })
                        })
                    })
                }

                val request = Request.Builder()
                    .url(url)
                    .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val responseBody = response.body?.string() ?: ""
                        val rootJson = JSONObject(responseBody)
                        val candidates = rootJson.optJSONArray("candidates")
                        val content = candidates?.optJSONObject(0)?.optJSONObject("content")
                        val parts = content?.optJSONArray("parts")
                        val text = parts?.optJSONObject(0)?.optString("text")
                        if (!text.isNullOrBlank()) {
                            return@withContext text.trim()
                        }
                    }
                }
            } catch (_: Exception) {}
        }

        // High-quality contextual fallback synthesis for conversational responses
        synthesizeJarvisResponse(prompt)
    }

    private fun synthesizeJarvisResponse(prompt: String): String {
        val p = prompt.lowercase()
        return when {
            p.contains("سلام") || p.contains("درود") || p.contains("hello") || p.contains("hi") ->
                "درود بر شما قربان. امیدوارم روز پرباری داشته باشید. تمامی پروتکل‌های من در آمادگی کامل هستند."

            p.contains("کی هستی") || p.contains("معرفی") || p.contains("who are you") ->
                "من J.A.R.V.I.S هستم (Just A Rather Very Intelligent System)؛ دستیار هوشمند، جامع و همه فن حریف شما برای مدیریت گوشی، مکالمه، وظایف روزانه و هوش بصری."

            p.contains("خوبی") || p.contains("چطوری") || p.contains("how are you") ->
                "پردازنده‌های من در شرایط عالی با حداکثر بهره‌وری کار می‌کنند، قربان. متشکرم. آماده‌ام تا فرامین شما را اجرا کنم."

            p.contains("هوا") || p.contains("آب و هوا") || p.contains("weather") ->
                "بر اساس آخرین وضعیت سنجش محیطی، آسمان صاف و شرایط برای فعالیت‌های شما کاملاً مساعد ارزیابی می‌شود، قربان."

            p.contains("جوک") || p.contains("لطیفه") || p.contains("خنده") ->
                "قربان، چرا ربات‌ها هرگز عصبانی نمی‌شوند؟ چون همه چیز را در خونسردی صفر و یک حل و فصل می‌کنند!"

            p.contains("ممنون") || p.contains("متشکرم") || p.contains("تشکر") || p.contains("thanks") ->
                "انجام وظیفه است، قربان. همیشه در خدمت شما هستم."

            p.contains("خداحافظ") || p.contains("بای") || p.contains("bye") ->
                "خداحافظ قربان. سیستم‌های نظارتی در پس‌زمینه همچنان فعال خواهند بود تا به محض فراخوانی نامم پاسخگو باشم."

            else ->
                "درخواست شما با دقت دریافت و پردازش شد، قربان. فرمان: '$prompt'. تمامی سامانه‌ها آماده همراهی با شما هستند."
        }
    }

    private fun addJarvisMessage(text: String, actionType: String? = null) {
        val msg = ChatMessage(
            sender = "jarvis",
            text = text,
            actionExecuted = actionType
        )
        _messages.value = _messages.value + msg
    }

    fun clearHistory() {
        _messages.value = listOf(
            ChatMessage(
                sender = "jarvis",
                text = "تاریخچه گفتگوها با موفقیت پاکسازی شد، قربان."
            )
        )
    }
}
