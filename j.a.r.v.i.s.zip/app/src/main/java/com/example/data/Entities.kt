package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "memories")
data class MemoryItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val content: String,
    val category: String = "general", // general, preference, project, person
    val isPinned: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "todos")
data class TodoItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String = "روزمره",
    val priority: String = "معمولی", // بالا, معمولی, پایین
    val isCompleted: Boolean = false,
    val dueDate: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "notes")
data class NoteItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val content: String,
    val colorHex: String = "#100E21",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "financial_records")
data class FinancialRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val amount: Long, // in Tomans / Rials / Currency
    val isExpense: Boolean = true,
    val category: String = "عمومی", // خوراک, سرگرمی, قبوض, خرید, متفرقه
    val date: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "routines")
data class AutomationRoutine(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val triggerPhrase: String,
    val actionType: String, // OPEN_APP, TOGGLE_FLASHLIGHT, SET_MODE, SPEAK, EMERGENCY
    val actionParam: String = "",
    val isEnabled: Boolean = true
)

@Entity(tableName = "emergency_contacts")
data class EmergencyContact(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phoneNumber: String,
    val relationship: String = "مخاطب اضطراری"
)
