package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface JarvisDao {
    // Memories
    @Query("SELECT * FROM memories ORDER BY isPinned DESC, timestamp DESC")
    fun getAllMemories(): Flow<List<MemoryItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(item: MemoryItem): Long

    @Delete
    suspend fun deleteMemory(item: MemoryItem)

    @Query("DELETE FROM memories")
    suspend fun clearMemories()

    // Todos
    @Query("SELECT * FROM todos ORDER BY isCompleted ASC, priority DESC, timestamp DESC")
    fun getAllTodos(): Flow<List<TodoItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTodo(item: TodoItem): Long

    @Update
    suspend fun updateTodo(item: TodoItem)

    @Delete
    suspend fun deleteTodo(item: TodoItem)

    // Notes
    @Query("SELECT * FROM notes ORDER BY timestamp DESC")
    fun getAllNotes(): Flow<List<NoteItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(item: NoteItem): Long

    @Delete
    suspend fun deleteNote(item: NoteItem)

    // Financial
    @Query("SELECT * FROM financial_records ORDER BY timestamp DESC")
    fun getAllFinancials(): Flow<List<FinancialRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFinancial(item: FinancialRecord): Long

    @Delete
    suspend fun deleteFinancial(item: FinancialRecord)

    // Routines
    @Query("SELECT * FROM routines ORDER BY id DESC")
    fun getAllRoutines(): Flow<List<AutomationRoutine>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoutine(item: AutomationRoutine): Long

    @Update
    suspend fun updateRoutine(item: AutomationRoutine)

    @Delete
    suspend fun deleteRoutine(item: AutomationRoutine)

    // Emergency Contacts
    @Query("SELECT * FROM emergency_contacts ORDER BY id ASC")
    fun getEmergencyContacts(): Flow<List<EmergencyContact>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmergencyContact(item: EmergencyContact): Long

    @Delete
    suspend fun deleteEmergencyContact(item: EmergencyContact)
}
