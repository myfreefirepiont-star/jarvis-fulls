package com.example.manager

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class InstalledApp(
    val name: String,
    val packageName: String,
    val icon: Drawable?,
    val isGame: Boolean = false,
    val isFavorite: Boolean = false
)

class AppManager(private val context: Context) {

    private val pm: PackageManager = context.packageManager

    suspend fun getInstalledApps(): List<InstalledApp> = withContext(Dispatchers.IO) {
        val appList = mutableListOf<InstalledApp>()
        try {
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
            
            for (ri in resolveInfos) {
                val pkgName = ri.activityInfo.packageName
                // Skip our own app if desired, or keep it
                val appName = ri.loadLabel(pm).toString()
                val icon = ri.loadIcon(pm)
                val appInfo = try {
                    pm.getApplicationInfo(pkgName, 0)
                } catch (_: Exception) {
                    null
                }
                
                val isGame = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    appInfo?.category == ApplicationInfo.CATEGORY_GAME
                } else {
                    appName.contains("game", ignoreCase = true) || pkgName.contains("game", ignoreCase = true)
                }

                appList.add(
                    InstalledApp(
                        name = appName,
                        packageName = pkgName,
                        icon = icon,
                        isGame = isGame
                    )
                )
            }
        } catch (_: Exception) {}

        appList.sortedBy { it.name.lowercase() }
    }

    fun launchAppByPackage(packageName: String): Boolean {
        return try {
            val launchIntent = pm.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                true
            } else {
                false
            }
        } catch (_: Exception) {
            false
        }
    }

    fun launchAppByNameOrAlias(query: String): Pair<Boolean, String> {
        val cleanQuery = query.trim().lowercase()

        // Known alias direct mappings
        val aliasMap = mapOf(
            "واتساپ" to listOf("com.whatsapp", "com.whatsapp.w4b"),
            "whatsapp" to listOf("com.whatsapp"),
            "تلگرام" to listOf("org.telegram.messenger", "org.telegram.plus", "org.thunderdog.challegram"),
            "telegram" to listOf("org.telegram.messenger"),
            "اینستاگرام" to listOf("com.instagram.android"),
            "instagram" to listOf("com.instagram.android"),
            "یوتیوب" to listOf("com.google.android.youtube"),
            "youtube" to listOf("com.google.android.youtube"),
            "روبیکا" to listOf("ir.resaneh1.iptv", "app.rbmain.a"),
            "ایتا" to listOf("ir.eitaa.messenger"),
            "اسنپ" to listOf("cab.snapp.passenger"),
            "دیجیکالا" to listOf("com.digikala"),
            "دیجی کالا" to listOf("com.digikala"),
            "گوگل" to listOf("com.google.android.googlequicksearchbox"),
            "کروم" to listOf("com.android.chrome"),
            "chrome" to listOf("com.android.chrome"),
            "مرورگر" to listOf("com.android.chrome", "org.mozilla.firefox"),
            "دوربین" to listOf("camera"),
            "camera" to listOf("camera"),
            "گالری" to listOf("gallery", "photos"),
            "gallery" to listOf("gallery", "photos"),
            "تنظیمات" to listOf("settings"),
            "settings" to listOf("settings"),
            "ماشین حساب" to listOf("calculator"),
            "calculator" to listOf("calculator"),
            "تقویم" to listOf("calendar"),
            "calendar" to listOf("calendar"),
            "موزیک" to listOf("music"),
            "آهنگ" to listOf("music"),
            "نقشه" to listOf("com.google.android.apps.maps", "neshan", "balad"),
            "maps" to listOf("com.google.android.apps.maps")
        )

        // Check explicit system targets first
        when {
            cleanQuery.contains("دوربین") || cleanQuery.contains("camera") -> {
                val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                return try {
                    context.startActivity(intent)
                    Pair(true, "دوربین اجرا شد، قربان.")
                } catch (_: Exception) {
                    Pair(false, "امکان باز کردن دوربین وجود ندارد.")
                }
            }
            cleanQuery.contains("ماشین حساب") || cleanQuery.contains("calculator") -> {
                val calcIntent = Intent().apply {
                    action = Intent.ACTION_MAIN
                    addCategory(Intent.CATEGORY_APP_CALCULATOR)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                return try {
                    context.startActivity(calcIntent)
                    Pair(true, "ماشین حساب باز شد.")
                } catch (_: Exception) {
                    Pair(false, "برنامه ماشین حساب یافت نشد.")
                }
            }
            cleanQuery.contains("تقویم") || cleanQuery.contains("calendar") -> {
                val calIntent = Intent().apply {
                    action = Intent.ACTION_MAIN
                    addCategory(Intent.CATEGORY_APP_CALENDAR)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                return try {
                    context.startActivity(calIntent)
                    Pair(true, "تقویم باز شد.")
                } catch (_: Exception) {
                    Pair(false, "برنامه تقویم یافت نشد.")
                }
            }
        }

        // Check aliases
        for ((alias, packages) in aliasMap) {
            if (cleanQuery.contains(alias)) {
                for (pkg in packages) {
                    if (launchAppByPackage(pkg)) {
                        return Pair(true, "$alias باز شد.")
                    }
                }
            }
        }

        // Fuzzy match installed apps
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
        for (ri in resolveInfos) {
            val appLabel = ri.loadLabel(pm).toString().lowercase()
            val pkg = ri.activityInfo.packageName
            if (appLabel.contains(cleanQuery) || cleanQuery.contains(appLabel)) {
                if (launchAppByPackage(pkg)) {
                    return Pair(true, "$appLabel باز شد.")
                }
            }
        }

        return Pair(false, "برنامه ای با نام '$query' در دستگاه شما پیدا نشد.")
    }

    fun openPlayStore(packageName: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(webIntent)
        }
    }
}
