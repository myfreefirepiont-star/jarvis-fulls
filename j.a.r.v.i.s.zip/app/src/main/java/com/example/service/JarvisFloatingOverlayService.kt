package com.example.service

import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.example.JarvisApp
import com.example.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class JarvisFloatingOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var isExpanded = false
    private val scope = CoroutineScope(Dispatchers.Main)

    @SuppressLint("ClickableViewAccessibility", "SetTextI18n")
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        windowManager = getSystemService(Context.WINDOW_SERVICE) as? WindowManager
        createFloatingHud()
    }

    @SuppressLint("ClickableViewAccessibility", "SetTextI18n")
    private fun createFloatingHud() {
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 200
        }

        // Create Container
        val rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }

        // Holographic Glowing Arc Reactor Button
        val arcButton = FrameLayout(this).apply {
            val bg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#120F2B"))
                setStroke(4, Color.parseColor("#00F0FF"))
            }
            background = bg
            val sizePx = (56 * resources.displayMetrics.density).toInt()
            layoutParams = LinearLayout.LayoutParams(sizePx, sizePx)
        }

        val icon = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_btn_speak_now)
            setColorFilter(Color.parseColor("#FFB703"))
            val padding = (12 * resources.displayMetrics.density).toInt()
            setPadding(padding, padding, padding, padding)
        }
        arcButton.addView(icon)

        // Expanded Panel
        val expandedCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            val cardBg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 24f * resources.displayMetrics.density
                setColor(Color.parseColor("#EE0B091A"))
                setStroke(2, Color.parseColor("#00F0FF"))
            }
            background = cardBg
            val p = (16 * resources.displayMetrics.density).toInt()
            setPadding(p, p, p, p)
            layoutParams = LinearLayout.LayoutParams(
                (280 * resources.displayMetrics.density).toInt(),
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleText = TextView(this).apply {
            text = "⚡ J.A.R.V.I.S HUD"
            setTextColor(Color.parseColor("#00F0FF"))
            textSize = 15f
            gravity = Gravity.CENTER
        }
        expandedCard.addView(titleText)

        val statusText = TextView(this).apply {
            text = "آماده دریافت فرمان..."
            setTextColor(Color.parseColor("#E0E0FF"))
            textSize = 13f
            val topP = (8 * resources.displayMetrics.density).toInt()
            setPadding(0, topP, 0, topP)
            gravity = Gravity.CENTER
        }
        expandedCard.addView(statusText)

        // Action Buttons Row
        val actionsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        fun createPillButton(label: String, colorHex: String, onClick: () -> Unit): TextView {
            return TextView(this).apply {
                text = label
                setTextColor(Color.parseColor(colorHex))
                val bgPill = GradientDrawable().apply {
                    cornerRadius = 16f * resources.displayMetrics.density
                    setColor(Color.parseColor("#252044"))
                    setStroke(1, Color.parseColor(colorHex))
                }
                background = bgPill
                val hP = (12 * resources.displayMetrics.density).toInt()
                val vP = (6 * resources.displayMetrics.density).toInt()
                setPadding(hP, vP, hP, vP)
                setOnClickListener { onClick() }
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setMargins(6, 4, 6, 4)
                }
                layoutParams = lp
            }
        }

        actionsRow.addView(createPillButton("🎙️ صحبت", "#00F0FF") {
            JarvisApp.instance.speechManager.startListening()
        })
        actionsRow.addView(createPillButton("💡 چراغ", "#FFB703") {
            val isOn = JarvisApp.instance.deviceManager.toggleTorch()
            statusText.text = if (isOn) "چراغ روشن شد" else "چراغ خاموش شد"
        })
        actionsRow.addView(createPillButton("🚀 برنامه", "#8A2BE2") {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
        })

        expandedCard.addView(actionsRow)

        rootLayout.addView(arcButton)
        rootLayout.addView(expandedCard)

        // Touch & Drag Handling for Arc Button
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isClick = true

        arcButton.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isClick = true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
                        isClick = false
                    }
                    params.x = initialX + dx
                    params.y = initialY + dy
                    windowManager?.updateViewLayout(rootLayout, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (isClick) {
                        isExpanded = !isExpanded
                        expandedCard.visibility = if (isExpanded) View.VISIBLE else View.GONE
                        if (isExpanded) {
                            JarvisApp.instance.deviceManager.playJarvisChime()
                        }
                    }
                    true
                }
                else -> false
            }
        }

        // Observe speech status in overlay
        scope.launch {
            JarvisApp.instance.speechManager.lastTranscript.collectLatest { t ->
                if (t.isNotBlank()) {
                    statusText.text = "شنیده شد: $t"
                }
            }
        }
        scope.launch {
            JarvisApp.instance.speechManager.isSpeaking.collectLatest { speaking ->
                if (speaking) {
                    statusText.text = "در حال صحبت: بله قربان..."
                }
            }
        }

        windowManager?.addView(rootLayout, params)
        overlayView = rootLayout
    }

    override fun onDestroy() {
        super.onDestroy()
        overlayView?.let { windowManager?.removeView(it) }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
