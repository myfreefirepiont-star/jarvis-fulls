package com.example.speech

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

class JarvisSpeechManager(private val context: Context) : RecognitionListener {

    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    private var speechRecognizer: SpeechRecognizer? = null
    private var isRecognizerActive = false

    // State flows for UI and Services
    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _isThinking = MutableStateFlow(false)
    val isThinking: StateFlow<Boolean> = _isThinking.asStateFlow()

    private val _rmsLevel = MutableStateFlow(0f)
    val rmsLevel: StateFlow<Float> = _rmsLevel.asStateFlow()

    private val _lastTranscript = MutableStateFlow("")
    val lastTranscript: StateFlow<String> = _lastTranscript.asStateFlow()

    // Wake word callbacks
    var onWakeWordDetected: (() -> Unit)? = null
    var onCommandRecognized: ((String) -> Unit)? = null

    // Preferences
    var isContinuousWakeEnabled = true
    var voicePitch: Float = 0.95f
    var voiceSpeed: Float = 1.0f

    init {
        initTts()
    }

    private fun initTts() {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isTtsReady = true
                val persianLocale = Locale("fa", "IR")
                val result = tts?.setLanguage(persianLocale)
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    // Fallback to default or English if Persian engine is missing
                    tts?.language = Locale.getDefault()
                }
                tts?.setPitch(voicePitch)
                tts?.setSpeechRate(voiceSpeed)

                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isSpeaking.value = true
                    }

                    override fun onDone(utteranceId: String?) {
                        _isSpeaking.value = false
                        // If continuous wake is enabled, resume listening after speaking!
                        if (isContinuousWakeEnabled && !isRecognizerActive) {
                            CoroutineScope(Dispatchers.Main).launch {
                                startListening()
                            }
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        _isSpeaking.value = false
                    }
                })
            }
        }
    }

    fun speak(text: String, onComplete: (() -> Unit)? = null) {
        if (!isTtsReady || text.isBlank()) {
            onComplete?.invoke()
            return
        }
        // Temporarily pause recognizer so TTS does not recognize itself
        pauseListening()
        _isSpeaking.value = true
        tts?.setPitch(voicePitch)
        tts?.setSpeechRate(voiceSpeed)

        val utteranceId = "jarvis_speak_${System.currentTimeMillis()}"
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stopSpeaking() {
        tts?.stop()
        _isSpeaking.value = false
    }

    fun setThinking(thinking: Boolean) {
        _isThinking.value = thinking
    }

    // Speech Recognizer
    fun startListening() {
        if (_isSpeaking.value) return // Don't listen while speaking
        CoroutineScope(Dispatchers.Main).launch {
            try {
                if (speechRecognizer == null) {
                    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                        setRecognitionListener(this@JarvisSpeechManager)
                    }
                }
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fa-IR")
                    putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, "fa-IR")
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                }
                speechRecognizer?.startListening(intent)
                isRecognizerActive = true
                _isListening.value = true
            } catch (_: Exception) {
                _isListening.value = false
                isRecognizerActive = false
            }
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
        } catch (_: Exception) {}
        _isListening.value = false
        isRecognizerActive = false
    }

    fun pauseListening() {
        try {
            speechRecognizer?.cancel()
        } catch (_: Exception) {}
        _isListening.value = false
        isRecognizerActive = false
    }

    fun destroy() {
        stopSpeaking()
        tts?.shutdown()
        try {
            speechRecognizer?.destroy()
        } catch (_: Exception) {}
        speechRecognizer = null
    }

    // RecognitionListener Callbacks
    override fun onReadyForSpeech(params: Bundle?) {
        _isListening.value = true
    }

    override fun onBeginningOfSpeech() {}

    override fun onRmsChanged(rmsdB: Float) {
        _rmsLevel.value = rmsdB.coerceIn(0f, 10f)
    }

    override fun onBufferReceived(buffer: ByteArray?) {}

    override fun onEndOfSpeech() {
        _isListening.value = false
        isRecognizerActive = false
    }

    override fun onError(error: Int) {
        _isListening.value = false
        isRecognizerActive = false
        // In continuous mode, safely retry listening after a brief delay if not destroyed
        if (isContinuousWakeEnabled && !_isSpeaking.value) {
            CoroutineScope(Dispatchers.Main).launch {
                kotlinx.coroutines.delay(1000)
                startListening()
            }
        }
    }

    override fun onResults(results: Bundle?) {
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val text = matches?.firstOrNull()?.trim() ?: ""
        if (text.isNotBlank()) {
            _lastTranscript.value = text
            handleRecognizedSpeech(text)
        } else if (isContinuousWakeEnabled && !_isSpeaking.value) {
            startListening()
        }
    }

    override fun onPartialResults(partialResults: Bundle?) {
        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val text = matches?.firstOrNull()?.trim() ?: ""
        if (text.isNotBlank()) {
            _lastTranscript.value = text
            // Check immediate wake word in partial results
            if (isWakeWord(text)) {
                pauseListening()
                onWakeWordDetected?.invoke()
            }
        }
    }

    override fun onEvent(eventType: Int, params: Bundle?) {}

    private fun isWakeWord(text: String): Boolean {
        val clean = text.lowercase()
        return clean == "جارویس" || clean == "jarvis" ||
                clean == "هی جارویس" || clean == "hey jarvis" ||
                clean == "الو جارویس" || clean == "سلام جارویس" ||
                clean.startsWith("جارویس ") || clean.startsWith("jarvis ")
    }

    private fun handleRecognizedSpeech(text: String) {
        val clean = text.lowercase()
        if (isWakeWord(clean)) {
            val commandAfterWake = clean
                .removePrefix("جارویس")
                .removePrefix("jarvis")
                .removePrefix("هی جارویس")
                .removePrefix("hey jarvis")
                .trim()

            if (commandAfterWake.isBlank()) {
                // Just wake word: trigger "بله قربان"
                onWakeWordDetected?.invoke()
            } else {
                // Wake word + inline command, e.g. "جارویس چراغ قوه رو روشن کن"
                onCommandRecognized?.invoke(commandAfterWake)
            }
        } else {
            // General speech command
            onCommandRecognized?.invoke(text)
        }
    }
}
