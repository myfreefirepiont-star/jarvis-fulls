package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ArcPurple
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.NeonCyan
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ArcReactorOrb(
    modifier: Modifier = Modifier,
    size: Dp = 200.dp,
    isListening: Boolean = false,
    isSpeaking: Boolean = false,
    isThinking: Boolean = false,
    onClick: () -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "arc_infinite")

    // Rotation animation
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isThinking) 1200 else 6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    // Pulse animation
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = if (isListening) 1.15f else if (isSpeaking) 1.08f else 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isListening) 600 else 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val coreColor = when {
        isListening -> NeonCyan
        isSpeaking -> JarvisGold
        isThinking -> ArcPurple
        else -> NeonCyan
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(size)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .testTag("arc_reactor_orb")
    ) {
        Canvas(modifier = Modifier.size(size * pulseScale)) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val radius = this.size.minDimension / 2f

            // Outer glowing ring
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(coreColor.copy(alpha = 0.35f), Color.Transparent),
                    center = center,
                    radius = radius
                ),
                radius = radius,
                center = center
            )

            // Outer structural boundary
            drawCircle(
                color = coreColor.copy(alpha = 0.5f),
                radius = radius * 0.92f,
                center = center,
                style = Stroke(width = 3.dp.toPx())
            )

            // Middle golden arc ring
            rotate(rotation, pivot = center) {
                val numArcs = 8
                val sweep = 30f
                for (i in 0 until numArcs) {
                    val startAngle = i * (360f / numArcs)
                    drawArc(
                        color = JarvisGold.copy(alpha = 0.85f),
                        startAngle = startAngle,
                        sweepAngle = sweep,
                        useCenter = false,
                        topLeft = Offset(center.x - radius * 0.78f, center.y - radius * 0.78f),
                        size = androidx.compose.ui.geometry.Size(radius * 1.56f, radius * 1.56f),
                        style = Stroke(width = 4.dp.toPx())
                    )
                }
            }

            // Counter-rotating inner cyan segments
            rotate(-rotation * 1.5f, pivot = center) {
                val segments = 12
                for (i in 0 until segments) {
                    val angle = Math.toRadians((i * (360.0 / segments)).toDouble())
                    val innerR = radius * 0.42f
                    val outerR = radius * 0.62f
                    val p1 = Offset((center.x + innerR * cos(angle)).toFloat(), (center.y + innerR * sin(angle)).toFloat())
                    val p2 = Offset((center.x + outerR * cos(angle)).toFloat(), (center.y + outerR * sin(angle)).toFloat())
                    drawLine(
                        color = NeonCyan.copy(alpha = 0.7f),
                        start = p1,
                        end = p2,
                        strokeWidth = 3.dp.toPx()
                    )
                }
            }

            // Core reactor orb
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.White, coreColor, Color(0xFF0F0E24)),
                    center = center,
                    radius = radius * 0.45f
                ),
                radius = radius * 0.42f,
                center = center
            )

            // Inner core ring
            drawCircle(
                color = JarvisGold,
                radius = radius * 0.44f,
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )
        }

        // Central Holographic Letter J
        Text(
            text = "J",
            color = Color.White,
            fontSize = (size.value * 0.28f).sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 1.sp
        )
    }
}
