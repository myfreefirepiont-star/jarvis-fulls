package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.JarvisApp
import com.example.manager.InstalledApp
import com.example.ui.components.HolographicButton
import com.example.ui.components.HolographicCard
import com.example.ui.theme.*

@Composable
fun AppsGamesScreen() {
    val app = JarvisApp.instance
    val appManager = app.appManager
    val brain = app.brain
    val activeMode by brain.activeMode.collectAsStateWithLifecycle()

    var installedApps by remember { mutableStateOf<List<InstalledApp>>(emptyList()) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedTab by remember { mutableIntStateOf(0) } // 0: All, 1: Games, 2: Popular
    var isLoading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        installedApps = appManager.getInstalledApps()
        isLoading = false
    }

    val filteredApps = remember(installedApps, searchQuery, selectedTab) {
        installedApps.filter { item ->
            val matchesSearch = item.name.contains(searchQuery, ignoreCase = true) ||
                    item.packageName.contains(searchQuery, ignoreCase = true)
            val matchesTab = when (selectedTab) {
                1 -> item.isGame
                else -> true
            }
            matchesSearch && matchesTab
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(horizontal = 16.dp)
            .padding(bottom = 80.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Gaming Mode Control Card
        HolographicCard(borderColor = ArcPurple.copy(alpha = 0.6f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "🎮 مرکز دستیار گیمینگ (Gaming HUD)",
                        color = ArcPurpleLight,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (activeMode == "گیمینگ") "حالت گیمینگ فعال است • بهینه‌سازی پردازنده و مهار اعلان‌ها" else "بهینه‌سازی بازی‌ها و پاسخ صوتی بدون خروج از بازی",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }

                Switch(
                    checked = activeMode == "گیمینگ",
                    onCheckedChange = { enable ->
                        if (enable) brain.processUserQuery("حالت گیمینگ را فعال کن", isVoice = true)
                        else brain.processUserQuery("حالت عادی را فعال کن", isVoice = true)
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = ArcPurple,
                        uncheckedThumbColor = TextMuted,
                        uncheckedTrackColor = DarkNavySurface
                    ),
                    modifier = Modifier.testTag("gaming_mode_switch")
                )
            }

            if (activeMode == "گیمینگ") {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Surface(color = DarkNavySurface, shape = RoundedCornerShape(8.dp)) {
                        Text("تاخیر شبکه: 22ms", color = SuccessGreen, fontSize = 11.sp, modifier = Modifier.padding(6.dp))
                    }
                    Surface(color = DarkNavySurface, shape = RoundedCornerShape(8.dp)) {
                        Text("حافظه آزاد: 4.8 GB", color = NeonCyan, fontSize = 11.sp, modifier = Modifier.padding(6.dp))
                    }
                    Surface(color = DarkNavySurface, shape = RoundedCornerShape(8.dp)) {
                        Text("نرخ فریم: 120 FPS", color = JarvisGold, fontSize = 11.sp, modifier = Modifier.padding(6.dp))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("جستجوی بازی یا برنامه...", color = TextMuted, fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = NeonCyan) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Default.Close, contentDescription = "پاک کردن", tint = TextSecondary)
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("app_search_field"),
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonCyan,
                unfocusedBorderColor = DarkNavyBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Tabs
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = DarkNavySurfaceElevated,
            contentColor = NeonCyan,
            divider = {}
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("همه برنامه‌ها (${installedApps.size})", fontSize = 12.sp) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("بازی‌ها", fontSize = 12.sp) }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // App List
        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = NeonCyan)
            }
        } else if (filteredApps.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = "برنامه‌ای با این مشخصات یافت نشد.",
                    color = TextSecondary,
                    fontSize = 14.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredApps) { appItem ->
                    Surface(
                        onClick = {
                            appManager.launchAppByPackage(appItem.packageName)
                        },
                        color = DarkNavySurfaceElevated,
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, DarkNavyBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("app_item_${appItem.packageName}")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Icon
                            if (appItem.icon != null) {
                                val bitmap = remember(appItem.packageName) {
                                    try {
                                        appItem.icon.toBitmap(96, 96).asImageBitmap()
                                    } catch (_: Exception) {
                                        null
                                    }
                                }
                                if (bitmap != null) {
                                    Image(
                                        bitmap = bitmap,
                                        contentDescription = null,
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                    )
                                } else {
                                    Icon(
                                        imageVector = if (appItem.isGame) Icons.Default.SportsEsports else Icons.Default.Apps,
                                        contentDescription = null,
                                        tint = if (appItem.isGame) ArcPurpleLight else NeonCyan,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = appItem.name,
                                    color = TextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = appItem.packageName,
                                    color = TextMuted,
                                    fontSize = 11.sp,
                                    maxLines = 1
                                )
                            }

                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "اجرا",
                                tint = NeonCyan,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
