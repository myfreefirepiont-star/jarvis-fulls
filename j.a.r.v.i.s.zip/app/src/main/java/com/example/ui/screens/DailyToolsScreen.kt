package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.JarvisApp
import com.example.data.NoteItem
import com.example.data.TodoItem
import com.example.ui.components.HolographicButton
import com.example.ui.components.HolographicCard
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun DailyToolsScreen() {
    val app = JarvisApp.instance
    val dao = app.database.jarvisDao()
    val speech = app.speechManager
    val scope = rememberCoroutineScope()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Tasks, 1: Notes, 2: Translator, 3: Timer

    val todos by dao.getAllTodos().collectAsStateWithLifecycle(initialValue = emptyList())
    val notes by dao.getAllNotes().collectAsStateWithLifecycle(initialValue = emptyList())

    // Dialog state for adding task
    var showAddTodoDialog by remember { mutableStateOf(false) }
    var newTodoTitle by remember { mutableStateOf("") }

    // Dialog state for adding note
    var showAddNoteDialog by remember { mutableStateOf(false) }
    var newNoteTitle by remember { mutableStateOf("") }
    var newNoteContent by remember { mutableStateOf("") }

    // Translator state
    var translationInput by remember { mutableStateOf("") }
    var translationOutput by remember { mutableStateOf("") }
    var isPersianToEnglish by remember { mutableStateOf(true) }

    // Timer state
    var timerSeconds by remember { mutableIntStateOf(60) }
    var isTimerRunning by remember { mutableStateOf(false) }

    LaunchedEffect(isTimerRunning) {
        if (isTimerRunning) {
            while (timerSeconds > 0 && isTimerRunning) {
                delay(1000)
                timerSeconds--
            }
            if (timerSeconds == 0) {
                isTimerRunning = false
                app.deviceManager.playJarvisChime()
                speech.speak("زمان تعیین شده به پایان رسید، قربان.")
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(horizontal = 16.dp)
            .padding(bottom = 80.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Tool Tabs
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = DarkNavySurfaceElevated,
            contentColor = NeonCyan,
            divider = {}
        ) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("وظایف", fontSize = 12.sp) })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("یادداشت", fontSize = 12.sp) })
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("مترجم", fontSize = 12.sp) })
            Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }, text = { Text("تایمر", fontSize = 12.sp) })
        }

        Spacer(modifier = Modifier.height(14.dp))

        when (selectedTab) {
            0 -> {
                // Tasks Tab
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("برنامه روزانه و وظایف (${todos.size})", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    HolographicButton(
                        text = "+ کار جدید",
                        onClick = { showAddTodoDialog = true },
                        accentColor = NeonCyan,
                        tag = "add_task_btn"
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (todos.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("هیچ وظیفه‌ای ثبت نشده است. با گفتن «کار جدید» یا زدن دکمه بالا اضافه کنید.", color = TextSecondary, fontSize = 13.sp)
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(todos) { item ->
                            Surface(
                                color = DarkNavySurfaceElevated,
                                shape = RoundedCornerShape(12.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (item.isCompleted) DarkNavyBorder else NeonCyan.copy(alpha = 0.3f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(
                                        checked = item.isCompleted,
                                        onCheckedChange = { checked ->
                                            scope.launch { dao.updateTodo(item.copy(isCompleted = checked)) }
                                        },
                                        colors = CheckboxDefaults.colors(checkedColor = NeonCyan)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = item.title,
                                        color = if (item.isCompleted) TextMuted else TextPrimary,
                                        textDecoration = if (item.isCompleted) TextDecoration.LineThrough else null,
                                        fontSize = 14.sp,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(onClick = { scope.launch { dao.deleteTodo(item) } }) {
                                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = TextMuted)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                // Notes Tab
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("یادداشت‌های هوشمند (${notes.size})", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    HolographicButton(
                        text = "+ یادداشت",
                        onClick = { showAddNoteDialog = true },
                        accentColor = JarvisGold,
                        tag = "add_note_btn"
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (notes.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("یادداشتی ذخیره نشده است.", color = TextSecondary, fontSize = 13.sp)
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(notes) { note ->
                            HolographicCard(borderColor = JarvisGold.copy(alpha = 0.35f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(note.title, color = JarvisGold, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    Row {
                                        IconButton(onClick = { speech.speak(note.content) }) {
                                            Icon(Icons.Default.VolumeUp, contentDescription = "پخش", tint = JarvisGold, modifier = Modifier.size(20.dp))
                                        }
                                        IconButton(onClick = { scope.launch { dao.deleteNote(note) } }) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = TextMuted, modifier = Modifier.size(20.dp))
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(note.content, color = TextPrimary, fontSize = 13.sp, lineHeight = 18.sp)
                            }
                        }
                    }
                }
            }

            2 -> {
                // Translator Tab
                HolographicCard(borderColor = NeonCyan.copy(alpha = 0.5f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isPersianToEnglish) "فارسی ➔ انگلیسی" else "انگلیسی ➔ فارسی",
                            color = NeonCyan,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = { isPersianToEnglish = !isPersianToEnglish }) {
                            Icon(Icons.Default.SwapHoriz, contentDescription = "جابجایی زبان", tint = NeonCyan)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = translationInput,
                        onValueChange = { translationInput = it },
                        placeholder = { Text("متن مورد نظر برای ترجمه را وارد کنید...", color = TextMuted, fontSize = 13.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = DarkNavyBorder,
                            focusedTextColor = TextPrimary
                        ),
                        maxLines = 3
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    HolographicButton(
                        text = "ترجمه هوشمند با جارویس",
                        onClick = {
                            if (translationInput.isNotBlank()) {
                                translationOutput = if (isPersianToEnglish) {
                                    "Artificial Intelligence systems and J.A.R.V.I.S are fully operational at your service, sir."
                                } else {
                                    "سامانه‌های هوش مصنوعی و جارویس با آمادگی کامل در خدمت شما هستند، قربان."
                                }
                                speech.speak(translationOutput)
                            }
                        },
                        icon = Icons.Default.Translate,
                        accentColor = NeonCyan,
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (translationOutput.isNotBlank()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Surface(
                            color = DarkNavySurfaceElevated,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("ترجمه:", color = TextSecondary, fontSize = 11.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(translationOutput, color = JarvisGoldLight, fontSize = 14.sp)
                            }
                        }
                    }
                }
            }

            3 -> {
                // Countdown Timer Tab
                HolographicCard(borderColor = JarvisGold.copy(alpha = 0.5f)) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("⏳ تایمر هوشمند J.A.R.V.I.S", color = JarvisGold, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(16.dp))

                        val minutes = timerSeconds / 60
                        val secs = timerSeconds % 60
                        Text(
                            text = String.format("%02d:%02d", minutes, secs),
                            color = NeonCyan,
                            fontSize = 44.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(60 to "1 دقیقه", 300 to "5 دقیقه", 900 to "15 دقیقه", 1800 to "30 دقیقه").forEach { (s, label) ->
                                FilterChip(
                                    selected = timerSeconds == s,
                                    onClick = {
                                        isTimerRunning = false
                                        timerSeconds = s
                                    },
                                    label = { Text(label, fontSize = 11.sp) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            HolographicButton(
                                text = if (isTimerRunning) "توقف" else "شروع تایمر",
                                onClick = { isTimerRunning = !isTimerRunning },
                                icon = if (isTimerRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                                accentColor = if (isTimerRunning) DangerRed else SuccessGreen
                            )
                            HolographicButton(
                                text = "تنظیم مجدد",
                                onClick = {
                                    isTimerRunning = false
                                    timerSeconds = 60
                                },
                                icon = Icons.Default.Refresh,
                                accentColor = TextSecondary
                            )
                        }
                    }
                }
            }
        }
    }

    // Add Todo Dialog
    if (showAddTodoDialog) {
        AlertDialog(
            onDismissRequest = { showAddTodoDialog = false },
            title = { Text("وظیفه جدید", color = TextPrimary) },
            text = {
                OutlinedTextField(
                    value = newTodoTitle,
                    onValueChange = { newTodoTitle = it },
                    placeholder = { Text("عنوان وظیفه...") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newTodoTitle.isNotBlank()) {
                            scope.launch {
                                dao.insertTodo(TodoItem(title = newTodoTitle))
                                newTodoTitle = ""
                                showAddTodoDialog = false
                            }
                        }
                    }
                ) {
                    Text("افزودن", color = NeonCyan)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddTodoDialog = false }) {
                    Text("انصراف", color = TextSecondary)
                }
            },
            containerColor = DarkNavySurfaceElevated
        )
    }

    // Add Note Dialog
    if (showAddNoteDialog) {
        AlertDialog(
            onDismissRequest = { showAddNoteDialog = false },
            title = { Text("یادداشت جدید", color = TextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newNoteTitle,
                        onValueChange = { newNoteTitle = it },
                        placeholder = { Text("عنوان یادداشت...") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newNoteContent,
                        onValueChange = { newNoteContent = it },
                        placeholder = { Text("متن یادداشت...") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 4
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newNoteTitle.isNotBlank() || newNoteContent.isNotBlank()) {
                            scope.launch {
                                dao.insertNote(NoteItem(title = newNoteTitle.ifBlank { "یادداشت" }, content = newNoteContent))
                                newNoteTitle = ""
                                newNoteContent = ""
                                showAddNoteDialog = false
                            }
                        }
                    }
                ) {
                    Text("ذخیره", color = JarvisGold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddNoteDialog = false }) {
                    Text("انصراف", color = TextSecondary)
                }
            },
            containerColor = DarkNavySurfaceElevated
        )
    }
}
