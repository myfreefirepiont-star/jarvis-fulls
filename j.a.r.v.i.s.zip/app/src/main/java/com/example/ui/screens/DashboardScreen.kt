package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.JarvisApp
import com.example.service.JarvisFloatingOverlayService
import com.example.service.JarvisVoiceService
import com.example.ui.components.ArcReactorOrb
import com.example.ui.components.HolographicButton
import com.example.ui.components.HolographicCard
import com.example.ui.components.SoundWaveVisualizer
import com.example.ui.components.TelemetryBadge
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
    onNavigateToChat: () -> Unit,
    onNavigateToApps: () -> Unit,
    onNavigateToVision: () -> Unit,
    onNavigateToEmergency: () -> Unit,
    onNavigateToTools: () -> Unit
) {
    val context = LocalContext.current
    val app = JarvisApp.instance
    val brain = app.brain
    val speech = app.speechManager
    val device = app.deviceManager

    val isListening by speech.isListening.collectAsStateWithLifecycle()
    val isSpeaking by speech.isSpeaking.collectAsStateWithLifecycle()
    val isThinking by speech.isThinking.collectAsStateWithLifecycle()
    val lastTranscript by speech.lastTranscript.collectAsStateWithLifecycle()
    val activeMode by brain.activeMode.collectAsStateWithLifecycle()

    var isTorchActive by remember { mutableStateOf(device.isTorchActive()) }
    var batteryLevel by remember { mutableIntStateOf(device.getBatteryLevel()) }
    var isCharging by remember { mutableStateOf(device.isBatteryCharging()) }
    var networkType by remember { mutableStateOf(device.getNetworkType()) }

    // Periodic telemetry update
    LaunchedEffect(Unit) {
        batteryLevel = device.getBatteryLevel()
        isCharging = device.isBatteryCharging()
        networkType = device.getNetworkType()
    }

    val timeString = remember {
        SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp)
    ) {
        // Holographic Header Telemetry Bar
        item {
            HolographicCard(borderColor = NeonCyan.copy(alpha = 0.4f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "J.A.R.V.I.S MKI",
                            color = NeonCyan,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "هوش مصنوعی مرکزی • آنلاین",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }

                    Surface(
                        color = when (activeMode) {
                            "اضطراری" -> DangerRed.copy(alpha = 0.2f)
                            "گیمینگ" -> ArcPurple.copy(alpha = 0.2f)
                            "رانندگی" -> JarvisGold.copy(alpha = 0.2f)
                            else -> NeonCyan.copy(alpha = 0.2f)
                        },
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            when (activeMode) {
                                "اضطراری" -> DangerRed
                                "گیمینگ" -> ArcPurple
                                "رانندگی" -> JarvisGold
                                else -> NeonCyan
                            }
                        )
                    ) {
                        Text(
                            text = "حالت: $activeMode",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TelemetryBadge(
                        label = "باتری",
                        value = if (batteryLevel >= 0) "$batteryLevel% ${if (isCharging) "⚡" else ""}" else "نامشخص",
                        icon = Icons.Default.BatteryChargingFull,
                        color = if (batteryLevel < 20) DangerRed else SuccessGreen
                    )
                    TelemetryBadge(
                        label = "شبکه",
                        value = networkType,
                        icon = Icons.Default.Wifi,
                        color = NeonCyan
                    )
                    TelemetryBadge(
                        label = "زمان",
                        value = timeString,
                        icon = Icons.Default.Schedule,
                        color = JarvisGold
                    )
                }
            }
        }

        // Central Holographic Arc Reactor Core
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                ArcReactorOrb(
                    size = 190.dp,
                    isListening = isListening,
                    isSpeaking = isSpeaking,
                    isThinking = isThinking,
                    onClick = {
                        brain.onWakeWordTriggered()
                    }
                )

                Spacer(modifier = Modifier.height(14.dp))

                val statusLabel = when {
                    isListening -> "🎙️ در حال شنیدن صدای شما..."
                    isThinking -> "⚡ در حال پردازش و استنتاج..."
                    isSpeaking -> "🗣️ «بله قربان!» در حال پاسخگویی..."
                    else -> "⚡ آماده به کار • نامم را صدا بزنید: «جارویس»"
                }

                Text(
                    text = statusLabel,
                    color = when {
                        isListening -> NeonCyan
                        isSpeaking -> JarvisGold
                        isThinking -> ArcPurpleLight
                        else -> TextPrimary
                    },
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                SoundWaveVisualizer(
                    isActive = isListening || isSpeaking,
                    barColor = if (isSpeaking) JarvisGold else NeonCyan
                )

                AnimatedVisibility(visible = lastTranscript.isNotBlank()) {
                    Surface(
                        color = DarkNavySurfaceElevated,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .padding(top = 8.dp)
                            .fillMaxWidth(0.9f)
                    ) {
                        Text(
                            text = "فرمان: \"$lastTranscript\"",
                            color = JarvisGoldLight,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // Large Primary Mic Button
        item {
            HolographicButton(
                text = if (isListening) "در حال شنیدن... (توقف لمس کنید)" else "شروع مکالمه با J.A.R.V.I.S (لمس کنید)",
                onClick = {
                    if (isListening) {
                        speech.stopListening()
                    } else {
                        speech.startListening()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("main_mic_button"),
                icon = Icons.Default.Mic,
                accentColor = if (isListening) JarvisGold else NeonCyan
            )
        }

        // System Services Quick Toggles: Floating Overlay & Background Wake
        item {
            HolographicCard(borderColor = ArcPurple.copy(alpha = 0.5f)) {
                Text(
                    text = "قابلیت‌های خارج از برنامه (Voice Anywhere & HUD)",
                    color = ArcPurpleLight,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    HolographicButton(
                        text = "دستیار شناور روی صفحه",
                        onClick = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
                                val intent = Intent(
                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:${context.packageName}")
                                )
                                context.startActivity(intent)
                            } else {
                                val intent = Intent(context, JarvisFloatingOverlayService::class.java)
                                context.startService(intent)
                            }
                        },
                        icon = Icons.Default.OpenInBrowser,
                        accentColor = ArcPurpleLight,
                        modifier = Modifier.weight(1f),
                        tag = "toggle_floating_hud"
                    )

                    HolographicButton(
                        text = "شنود دائمی خارج برنامه",
                        onClick = {
                            val intent = Intent(context, JarvisVoiceService::class.java)
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                context.startForegroundService(intent)
                            } else {
                                context.startService(intent)
                            }
                        },
                        icon = Icons.Default.Hearing,
                        accentColor = NeonCyan,
                        modifier = Modifier.weight(1f),
                        tag = "start_bg_voice_service"
                    )
                }
            }
        }

        // Quick Controls & Tools Grid
        item {
            Text(
                text = "دسترسی سریع و فرمان‌های هوشمند",
                color = TextSecondary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Flashlight
                    HolographicCard(
                        modifier = Modifier.weight(1f),
                        borderColor = if (isTorchActive) JarvisGold else DarkNavyBorder,
                        onClick = {
                            isTorchActive = device.toggleTorch()
                        }
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isTorchActive) Icons.Default.FlashlightOn else Icons.Default.FlashlightOff,
                                contentDescription = null,
                                tint = if (isTorchActive) JarvisGold else TextSecondary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("چراغ‌قوه", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(if (isTorchActive) "روشن" else "خاموش", color = TextSecondary, fontSize = 11.sp)
                            }
                        }
                    }

                    // Smart Camera Vision
                    HolographicCard(
                        modifier = Modifier.weight(1f),
                        borderColor = NeonCyan.copy(alpha = 0.5f),
                        onClick = onNavigateToVision
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CameraAlt, contentDescription = null, tint = NeonCyan)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("هوش بینایی", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("اسکن و تحلیل OCR", color = TextSecondary, fontSize = 11.sp)
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Apps & Games Hub
                    HolographicCard(
                        modifier = Modifier.weight(1f),
                        borderColor = ArcPurple.copy(alpha = 0.5f),
                        onClick = onNavigateToApps
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.SportsEsports, contentDescription = null, tint = ArcPurpleLight)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("بازی‌ها و برنامه‌ها", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("گیمینگ و اجرای صوتی", color = TextSecondary, fontSize = 11.sp)
                            }
                        }
                    }

                    // Emergency & SOS
                    HolographicCard(
                        modifier = Modifier.weight(1f),
                        borderColor = DangerRed.copy(alpha = 0.5f),
                        onClick = onNavigateToEmergency
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = DangerRed)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("سیستم اضطراری", color = DangerRed, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("SOS و تماس فرار", color = TextSecondary, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        // Quick Command Prompts (Tap to execute)
        item {
            Text(
                text = "فرمان‌های صوتی متداول (لمس جهت آزمایش)",
                color = TextSecondary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(8.dp))

            val quickPrompts = listOf(
                "جارویس",
                "چراغ قوه رو روشن کن",
                "وضعیت باتری چطوره؟",
                "حالت گیمینگ رو فعال کن",
                "دوربین رو باز کن",
                "یادداشت بنویس جلسه فردا ساعت ۱۰",
                "یادت باشه من عاشق کدنویسی هستم"
            )

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(quickPrompts) { prompt ->
                    Surface(
                        onClick = { brain.processUserQuery(prompt, isVoice = true) },
                        color = DarkNavySurfaceElevated,
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan.copy(alpha = 0.3f))
                    ) {
                        Text(
                            text = prompt,
                            color = NeonCyanLight,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }
    }
}
