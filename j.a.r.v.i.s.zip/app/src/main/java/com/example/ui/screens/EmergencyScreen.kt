package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.JarvisApp
import com.example.data.EmergencyContact
import com.example.ui.components.HolographicButton
import com.example.ui.components.HolographicCard
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun EmergencyScreen() {
    val context = LocalContext.current
    val app = JarvisApp.instance
    val device = app.deviceManager
    val dao = app.database.jarvisDao()
    val speech = app.speechManager
    val scope = rememberCoroutineScope()

    var isSirenPlaying by remember { mutableStateOf(device.isSirenPlaying()) }
    var isFakeCallActive by remember { mutableStateOf(false) }
    var isCallAnswered by remember { mutableStateOf(false) }
    var fakeCallTimer by remember { mutableIntStateOf(0) }

    val contacts by dao.getEmergencyContacts().collectAsStateWithLifecycle(initialValue = emptyList())
    var showAddContactDialog by remember { mutableStateOf(false) }
    var contactName by remember { mutableStateOf("") }
    var contactPhone by remember { mutableStateOf("") }

    // Fake call timer
    LaunchedEffect(isCallAnswered) {
        if (isCallAnswered) {
            fakeCallTimer = 0
            while (isCallAnswered) {
                delay(1000)
                fakeCallTimer++
            }
        }
    }

    if (isFakeCallActive) {
        // Realistic Incoming Fake Call UI
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF070B16))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(top = 48.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .clip(CircleShape)
                            .background(DarkNavySurfaceElevated)
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(56.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "مرکز ستاد فرماندهی استارک",
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isCallAnswered) String.format("%02d:%02d", fakeCallTimer / 60, fakeCallTimer % 60) else "تماس اضطراری ورودی...",
                        color = if (isCallAnswered) SuccessGreen else TextSecondary,
                        fontSize = 15.sp
                    )
                }

                if (!isCallAnswered) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 60.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        // Decline Button
                        IconButton(
                            onClick = {
                                isFakeCallActive = false
                                device.vibrate(100)
                            },
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(DangerRed)
                        ) {
                            Icon(Icons.Default.CallEnd, contentDescription = "رد تماس", tint = Color.White, modifier = Modifier.size(32.dp))
                        }

                        // Accept Button
                        IconButton(
                            onClick = {
                                isCallAnswered = true
                                device.vibrate(100)
                                speech.speak("قربان، موقعیت اضطراری در ستاد گزارش شده است. لطفاً فوراً جلسه را ترک کرده و به پایگاه ملحق شوید!")
                            },
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(SuccessGreen)
                        ) {
                            Icon(Icons.Default.Call, contentDescription = "پاسخ به تماس", tint = Color.White, modifier = Modifier.size(32.dp))
                        }
                    }
                } else {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(bottom = 60.dp)
                    ) {
                        Text(
                            text = "صدا از بلندگوی استتاری پخش می‌شود...",
                            color = JarvisGoldLight,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        IconButton(
                            onClick = {
                                isFakeCallActive = false
                                isCallAnswered = false
                                speech.stopSpeaking()
                            },
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(DangerRed)
                        ) {
                            Icon(Icons.Default.CallEnd, contentDescription = "قطع تماس", tint = Color.White, modifier = Modifier.size(32.dp))
                        }
                    }
                }
            }
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(horizontal = 16.dp)
            .padding(bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 16.dp)
    ) {
        // Emergency Banner
        item {
            HolographicCard(borderColor = DangerRed.copy(alpha = 0.8f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = DangerRed,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "سامانه امنیتی و اضطراری J.A.R.V.I.S",
                            color = DangerRed,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "پروتکل‌های نجات، آژیر هشدار، ارسال موقعیت و تماس ساختگی فرار",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Primary SOS Actions
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                HolographicButton(
                    text = "🚨 خطر ۱ (SOS اضطراری)",
                    onClick = {
                        val smsIntent = Intent(Intent.ACTION_SENDTO).apply {
                            data = Uri.parse("smsto:")
                            putExtra("sms_body", "هشدار اضطراری J.A.R.V.I.S: من در شرایط ناامن قرار دارم و به کمک نیاز دارم.")
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        }
                        try {
                            context.startActivity(smsIntent)
                        } catch (_: Exception) {}
                    },
                    accentColor = DangerRed,
                    modifier = Modifier.weight(1f),
                    tag = "danger_1_btn"
                )

                HolographicButton(
                    text = if (isSirenPlaying) "توقف آژیر" else "🔊 آژیر با صدای بلند",
                    onClick = {
                        if (isSirenPlaying) {
                            device.stopEmergencySiren()
                            isSirenPlaying = false
                        } else {
                            device.startEmergencySiren()
                            isSirenPlaying = true
                        }
                    },
                    accentColor = if (isSirenPlaying) DangerRed else JarvisGold,
                    modifier = Modifier.weight(1f),
                    tag = "siren_toggle_btn"
                )
            }
        }

        // Fake Call Escape Feature
        item {
            HolographicCard(borderColor = NeonCyan.copy(alpha = 0.5f)) {
                Text(
                    text = "📞 تماس ساختگی فرار (Fake Call Escape)",
                    color = NeonCyan,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "شبیه‌سازی یک تماس تلفنی ورودی فوری از سوی ستاد فرماندهی با پیام صوتی واقعی تا بتوانید به راحتی از موقعیت‌های معذب‌کننده یا ناامن جدا شوید.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                HolographicButton(
                    text = "زنگ زدن گوشی با تماس ساختگی",
                    onClick = {
                        isFakeCallActive = true
                        isCallAnswered = false
                        device.vibrate(300)
                    },
                    icon = Icons.Default.PhoneCallback,
                    accentColor = NeonCyan,
                    modifier = Modifier.fillMaxWidth(),
                    tag = "trigger_fake_call_btn"
                )
            }
        }

        // Emergency Contacts Section
        item {
            HolographicCard(borderColor = DarkNavyBorder) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "مخاطبین اضطراری (${contacts.size})",
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    HolographicButton(
                        text = "+ افزودن",
                        onClick = { showAddContactDialog = true },
                        accentColor = JarvisGold,
                        tag = "add_emergency_contact_btn"
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                if (contacts.isEmpty()) {
                    Text(
                        text = "هنوز مخاطب اضطراری ثبت نشده است. برای مواقع بحرانی حداقل یک شماره ذخیره کنید.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                } else {
                    contacts.forEach { contact ->
                        Surface(
                            color = DarkNavySurface,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(contact.name, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                    Text(contact.phoneNumber, color = TextSecondary, fontSize = 11.sp)
                                }
                                Row {
                                    IconButton(onClick = {
                                        val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${contact.phoneNumber}")).apply {
                                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                        }
                                        try { context.startActivity(dialIntent) } catch (_: Exception) {}
                                    }) {
                                        Icon(Icons.Default.Phone, contentDescription = "تماس", tint = SuccessGreen)
                                    }
                                    IconButton(onClick = { scope.launch { dao.deleteEmergencyContact(contact) } }) {
                                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = TextMuted)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddContactDialog) {
        AlertDialog(
            onDismissRequest = { showAddContactDialog = false },
            title = { Text("مخاطب اضطراری جدید", color = TextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = contactName,
                        onValueChange = { contactName = it },
                        placeholder = { Text("نام مخاطب (مثلا: پدر / همسر)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = contactPhone,
                        onValueChange = { contactPhone = it },
                        placeholder = { Text("شماره تماس...") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (contactName.isNotBlank() && contactPhone.isNotBlank()) {
                        scope.launch {
                            dao.insertEmergencyContact(
                                EmergencyContact(name = contactName, phoneNumber = contactPhone)
                            )
                            contactName = ""
                            contactPhone = ""
                            showAddContactDialog = false
                        }
                    }
                }) {
                    Text("ثبت", color = NeonCyan)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddContactDialog = false }) {
                    Text("انصراف", color = TextSecondary)
                }
            },
            containerColor = DarkNavySurfaceElevated
        )
    }
}
