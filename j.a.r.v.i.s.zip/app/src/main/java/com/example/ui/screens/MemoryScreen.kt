package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.JarvisApp
import com.example.data.MemoryItem
import com.example.ui.components.HolographicButton
import com.example.ui.components.HolographicCard
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun MemoryScreen() {
    val app = JarvisApp.instance
    val dao = app.database.jarvisDao()
    val speech = app.speechManager
    val scope = rememberCoroutineScope()

    val memories by dao.getAllMemories().collectAsStateWithLifecycle(initialValue = emptyList())
    var showAddDialog by remember { mutableStateOf(false) }
    var memoryTitle by remember { mutableStateOf("") }
    var memoryContent by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(horizontal = 16.dp)
            .padding(bottom = 80.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        HolographicCard(borderColor = ArcPurple.copy(alpha = 0.6f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "🧠 هسته حافظه هوشمند (Memory Intelligence)",
                        color = ArcPurpleLight,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "اطلاعات، ترجیحات و نکات مهمی که جارویس درباره شما به خاطر سپرده است.",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }

                HolographicButton(
                    text = "+ حافظه",
                    onClick = { showAddDialog = true },
                    accentColor = ArcPurpleLight,
                    tag = "add_memory_btn"
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (memories.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = null,
                        tint = TextMuted,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "حافظه جارویس در حال حاضر خالی است.\nبا گفتن «یادت باشه که...» یا دکمه بالا نکته‌ای اضافه کنید.",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(memories) { mem ->
                    HolographicCard(borderColor = DarkNavyBorder) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Bookmark, contentDescription = null, tint = JarvisGold, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(mem.title, color = JarvisGold, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                            IconButton(onClick = { scope.launch { dao.deleteMemory(mem) } }) {
                                Icon(Icons.Default.Delete, contentDescription = "حذف", tint = TextMuted, modifier = Modifier.size(20.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(mem.content, color = TextPrimary, fontSize = 13.sp, lineHeight = 19.sp)
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("ثبت نکته در حافظه جارویس", color = TextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = memoryTitle,
                        onValueChange = { memoryTitle = it },
                        placeholder = { Text("موضوع یا دسته‌بندی...") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = memoryContent,
                        onValueChange = { memoryContent = it },
                        placeholder = { Text("متن ترجیح یا نکته...") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 4
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (memoryContent.isNotBlank()) {
                        scope.launch {
                            dao.insertMemory(
                                MemoryItem(
                                    title = memoryTitle.ifBlank { "دانش اختصاصی" },
                                    content = memoryContent
                                )
                            )
                            speech.speak("اطلاعات در حافظه بلندمدت من ذخیره شد، قربان.")
                            memoryTitle = ""
                            memoryContent = ""
                            showAddDialog = false
                        }
                    }
                }) {
                    Text("ذخیره در حافظه", color = ArcPurpleLight)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("انصراف", color = TextSecondary)
                }
            },
            containerColor = DarkNavySurfaceElevated
        )
    }
}
