package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.JarvisApp
import com.example.service.JarvisFloatingOverlayService
import com.example.service.JarvisVoiceService
import com.example.ui.components.HolographicButton
import com.example.ui.components.HolographicCard
import com.example.ui.theme.*

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val app = JarvisApp.instance
    val speech = app.speechManager

    var isBgVoiceRunning by remember { mutableStateOf(speech.isContinuousWakeEnabled) }
    var isFloatingOverlayActive by remember { mutableStateOf(false) }
    var voicePitch by remember { mutableFloatStateOf(speech.voicePitch) }
    var voiceSpeed by remember { mutableFloatStateOf(speech.voiceSpeed) }

    // Permissions check states
    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    val micLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasMicPermission = granted
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(horizontal = 16.dp)
            .padding(bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 16.dp)
    ) {
        // System Services
        item {
            HolographicCard(borderColor = NeonCyan.copy(alpha = 0.5f)) {
                Text(
                    text = "سرویس‌های پس‌زمینه و دستیار شناور",
                    color = NeonCyan,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(10.dp))

                // Background Voice Wake
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "شنود دائمی خارج از برنامه (پس‌زمینه)",
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "وقتی داخل هیچ برنامه‌ای نیستید با گفتن «جارویس» پاسخ می‌دهد: «بله قربان!»",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }

                    Switch(
                        checked = isBgVoiceRunning,
                        onCheckedChange = { enable ->
                            isBgVoiceRunning = enable
                            speech.isContinuousWakeEnabled = enable
                            val intent = Intent(context, JarvisVoiceService::class.java)
                            if (enable) {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    context.startForegroundService(intent)
                                } else {
                                    context.startService(intent)
                                }
                            } else {
                                context.stopService(intent)
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = NeonCyan
                        ),
                        modifier = Modifier.testTag("bg_voice_switch")
                    )
                }

                Divider(color = DarkNavyBorder, modifier = Modifier.padding(vertical = 10.dp))

                // Floating Assistant
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "دکمه شناور روی برنامه‌ها (Overlay HUD)",
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "آیکون آرک-ری‌اکتور شناور برای دسترسی سریع هنگام بازی یا کار با سایر برنامه‌ها",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }

                    Switch(
                        checked = isFloatingOverlayActive,
                        onCheckedChange = { enable ->
                            if (enable && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
                                val intent = Intent(
                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:${context.packageName}")
                                )
                                context.startActivity(intent)
                            } else {
                                isFloatingOverlayActive = enable
                                val intent = Intent(context, JarvisFloatingOverlayService::class.java)
                                if (enable) context.startService(intent) else context.stopService(intent)
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = ArcPurpleLight
                        ),
                        modifier = Modifier.testTag("floating_overlay_switch")
                    )
                }
            }
        }

        // Voice Engine Settings
        item {
            HolographicCard(borderColor = JarvisGold.copy(alpha = 0.4f)) {
                Text(
                    text = "تنظیمات لحن و صدای دستیار (TTS)",
                    color = JarvisGold,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text("زیر و بمی صدا (Pitch): ${(voicePitch * 100).toInt()}%", color = TextSecondary, fontSize = 12.sp)
                Slider(
                    value = voicePitch,
                    onValueChange = {
                        voicePitch = it
                        speech.voicePitch = it
                    },
                    valueRange = 0.5f..1.5f,
                    colors = SliderDefaults.colors(thumbColor = JarvisGold, activeTrackColor = JarvisGold)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text("سرعت گفتار (Speed): ${(voiceSpeed * 100).toInt()}%", color = TextSecondary, fontSize = 12.sp)
                Slider(
                    value = voiceSpeed,
                    onValueChange = {
                        voiceSpeed = it
                        speech.voiceSpeed = it
                    },
                    valueRange = 0.7f..1.5f,
                    colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
                )

                Spacer(modifier = Modifier.height(8.dp))

                HolographicButton(
                    text = "تست صدای «بله قربان!»",
                    onClick = {
                        speech.speak("بله قربان! کلیه سامانه‌های صوتی در سطح بهینه عمل می‌کنند.")
                    },
                    icon = Icons.Default.VolumeUp,
                    accentColor = JarvisGold,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Permissions Matrix
        item {
            HolographicCard(borderColor = DarkNavyBorder) {
                Text(
                    text = "وضعیت مجوزهای سیستم‌عامل",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("مجوز میکروفون (صدا)", color = TextPrimary, fontSize = 13.sp)
                        Text(if (hasMicPermission) "فعال و مجاز" else "غیرفعال", color = if (hasMicPermission) SuccessGreen else DangerRed, fontSize = 11.sp)
                    }
                    if (!hasMicPermission) {
                        Button(
                            onClick = { micLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                        ) {
                            Text("درخواست مجوز", color = Color.Black, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // About Jarvis
        item {
            HolographicCard(borderColor = DarkNavyBorder) {
                Text("درباره J.A.R.V.I.S", color = NeonCyan, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "نسخه ۱.۰ هولوگرافیک • معماری یکپارچه AI Brain بر بستر Gemini API و سیستم مدیریت سخت‌افزار اندروید.\nتوسعه یافته به عنوان دستیار وفادار و همه‌جانبه.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }
        }
    }
}
