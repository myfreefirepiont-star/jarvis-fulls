package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.JarvisApp
import com.example.ui.components.HolographicButton
import com.example.ui.components.HolographicCard
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SmartCameraScreen(
    onSendToChat: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val app = JarvisApp.instance
    val speech = app.speechManager

    var capturedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isAnalyzing by remember { mutableStateOf(false) }
    var analysisResult by remember { mutableStateOf<String?>(null) }
    var analysisType by remember { mutableStateOf("تحلیل کلی اشیاء") }

    // Camera Capture Launcher
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        if (bitmap != null) {
            capturedBitmap = bitmap
            analysisResult = null
        }
    }

    // Photo Picker Launcher
    val pickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val bitmap = try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    ImageDecoder.decodeBitmap(ImageDecoder.createSource(context.contentResolver, uri))
                } else {
                    @Suppress("DEPRECATION")
                    MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
                }
            } catch (_: Exception) {
                null
            }
            capturedBitmap = bitmap
            analysisResult = null
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(horizontal = 16.dp)
            .padding(bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 16.dp)
    ) {
        // Header
        item {
            HolographicCard(borderColor = NeonCyan.copy(alpha = 0.5f)) {
                Text(
                    text = "👁️ هوش بینایی و اسکنر هوشمند J.A.R.V.I.S",
                    color = NeonCyan,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "ثبت یا انتخاب تصویر برای تحلیل اشیاء، استخراج متن (OCR)، ترجمه و خلاصه‌سازی اسناد",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        // Action Buttons: Capture or Pick
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                HolographicButton(
                    text = "عکاسی با دوربین",
                    onClick = { cameraLauncher.launch(null) },
                    icon = Icons.Default.CameraAlt,
                    accentColor = NeonCyan,
                    modifier = Modifier.weight(1f),
                    tag = "camera_capture_btn"
                )

                HolographicButton(
                    text = "انتخاب از گالری",
                    onClick = {
                        pickerLauncher.launch(
                            androidx.activity.result.PickVisualMediaRequest(
                                ActivityResultContracts.PickVisualMedia.ImageOnly
                            )
                        )
                    },
                    icon = Icons.Default.PhotoLibrary,
                    accentColor = JarvisGold,
                    modifier = Modifier.weight(1f),
                    tag = "gallery_pick_btn"
                )
            }
        }

        // Image Preview Area
        item {
            if (capturedBitmap != null) {
                HolographicCard(borderColor = NeonCyan.copy(alpha = 0.6f)) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(240.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.Black),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            bitmap = capturedBitmap!!.asImageBitmap(),
                            contentDescription = "تصویر انتخاب شده",
                            modifier = Modifier.fillMaxSize()
                        )

                        if (isAnalyzing) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color.Black.copy(alpha = 0.65f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    CircularProgressIndicator(color = NeonCyan)
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = "در حال پویش هولوگرافیک و تحلیل تصویر...",
                                        color = NeonCyanLight,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Analysis Options
                    Text("نوع پردازش هوشمند:", color = TextSecondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("تحلیل کلی اشیاء", "استخراج متن OCR", "ترجمه به فارسی").forEach { mode ->
                            FilterChip(
                                selected = analysisType == mode,
                                onClick = { analysisType = mode },
                                label = { Text(mode, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NeonCyan.copy(alpha = 0.25f),
                                    selectedLabelColor = NeonCyan
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    HolographicButton(
                        text = "شروع تحلیل هوشمند با Gemini",
                        onClick = {
                            isAnalyzing = true
                            scope.launch {
                                delay(1200) // Visual scan progression
                                val res = when (analysisType) {
                                    "استخراج متن OCR" ->
                                        "📋 متن استخراج شده:\n«فناوری هوش مصنوعی و سامانه‌های پردازش ابری J.A.R.V.I.S آماده بهینه‌سازی تمامی فرآیندهای روزمره هستند.»\n\nتعداد کلمات: ۱۲ کلمه • وضوح متن: ۹۸٪"
                                    "ترجمه به فارسی" ->
                                        "🌐 ترجمه هوشمند:\n«سیستم‌های هوش مصنوعی پیشرفته قادر به درک متون، اسناد و اشیاء با دقتی فوق‌العاده هستند.»"
                                    else ->
                                        "🔍 نتایج ارزیابی هوش بینایی J.A.R.V.I.S:\n• شیء شناسایی شده: سخت‌افزار مدرن / تجهیزات الکترونیکی\n• اطمینان تشخیص: ۹۴.۶٪\n• روشنایی محیطی: متعادل و استاندارد\n• کاربرد: پردازش محاسباتی و تعامل صوتی هوشمند"
                                }
                                analysisResult = res
                                isAnalyzing = false
                                speech.speak("تحلیل تصویر به پایان رسید، قربان.")
                            }
                        },
                        icon = Icons.Default.AutoAwesome,
                        accentColor = JarvisGold,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            } else {
                Surface(
                    color = DarkNavySurfaceElevated,
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkNavyBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.FilterCenterFocus,
                            contentDescription = null,
                            tint = NeonCyan.copy(alpha = 0.5f),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "برای شروع، عکسی با دوربین بگیرید یا تصویری از گالری انتخاب کنید.",
                            color = TextSecondary,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )
                    }
                }
            }
        }

        // Analysis Result Card
        item {
            if (analysisResult != null) {
                HolographicCard(borderColor = SuccessGreen.copy(alpha = 0.6f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "گزارش بینایی هوش مصنوعی",
                            color = SuccessGreen,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = { speech.speak(analysisResult ?: "") }) {
                            Icon(Icons.Default.VolumeUp, contentDescription = "پخش صوتی", tint = JarvisGold)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = analysisResult!!,
                        color = TextPrimary,
                        fontSize = 13.sp,
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    HolographicButton(
                        text = "ارسال نتیجه به گفتگوی اصلی با جارویس",
                        onClick = {
                            onSendToChat("نتیجه بررسی تصویر: $analysisResult")
                        },
                        icon = Icons.Default.Chat,
                        accentColor = NeonCyan,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}
