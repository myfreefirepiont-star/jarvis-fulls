package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian & Futuristic Deep Space Backgrounds
val ObsidianBackground = Color(0xFF08070F)
val DarkNavySurface = Color(0xFF100E21)
val DarkNavySurfaceElevated = Color(0xFF181530)
val DarkNavyBorder = Color(0xFF2C2454)

// Holographic Accents
val NeonCyan = Color(0xFF00F0FF)
val NeonCyanLight = Color(0xFF70FAFF)
val NeonCyanGlow = Color(0x3300F0FF)

val JarvisGold = Color(0xFFFFB703)
val JarvisGoldLight = Color(0xFFFFD166)
val JarvisGoldGlow = Color(0x33FFB703)

val ArcPurple = Color(0xFF8A2BE2)
val ArcPurpleLight = Color(0xFFB57EDC)
val ArcPurpleGlow = Color(0x338A2BE2)

val DangerRed = Color(0xFFFF3366)
val SuccessGreen = Color(0xFF00E676)

// Text Colors
val TextPrimary = Color(0xFFF0F4F8)
val TextSecondary = Color(0xFF9E9EAF)
val TextMuted = Color(0xFF6B6A7F)
