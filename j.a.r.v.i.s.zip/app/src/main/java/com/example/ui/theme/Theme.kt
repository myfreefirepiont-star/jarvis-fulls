package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val JarvisColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = Color(0xFF002026),
    primaryContainer = Color(0xFF003640),
    onPrimaryContainer = NeonCyanLight,
    
    secondary = JarvisGold,
    onSecondary = Color(0xFF261900),
    secondaryContainer = Color(0xFF3D2700),
    onSecondaryContainer = JarvisGoldLight,
    
    tertiary = ArcPurpleLight,
    onTertiary = Color(0xFF28004B),
    tertiaryContainer = Color(0xFF420077),
    onTertiaryContainer = Color(0xFFF2DAFF),
    
    background = ObsidianBackground,
    onBackground = TextPrimary,
    
    surface = DarkNavySurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkNavySurfaceElevated,
    onSurfaceVariant = TextSecondary,
    
    outline = DarkNavyBorder,
    outlineVariant = Color(0xFF383260),
    
    error = DangerRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = JarvisColorScheme,
        typography = Typography,
        content = content
    )
}
