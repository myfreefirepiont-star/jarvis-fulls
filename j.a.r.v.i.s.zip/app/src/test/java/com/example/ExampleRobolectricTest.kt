package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.MemoryItem
import com.example.data.TodoItem
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context verifies Jarvis app name`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("J.A.R.V.I.S", appName)
    }

    @Test
    fun `verify MemoryItem data integrity`() {
        val item = MemoryItem(
            title = "ترجیح کاربر",
            content = "نام کاربر: امیر",
            category = "preference"
        )
        assertEquals("ترجیح کاربر", item.title)
        assertEquals("نام کاربر: امیر", item.content)
    }

    @Test
    fun `verify TodoItem data integrity`() {
        val todo = TodoItem(
            title = "بررسی سیستم‌های مرکزی",
            priority = "بالا"
        )
        assertEquals("بررسی سیستم‌های مرکزی", todo.title)
        assertEquals("بالا", todo.priority)
    }
}
