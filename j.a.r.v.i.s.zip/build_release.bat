@echo off
chcp 65001 > nul
REM ==============================================================================
REM اسکریپت ساخت فایل نصبی APK برای پروژه J.A.R.V.I.S (ویندوز)
REM ==============================================================================

echo ==========================================================
echo    شروع فرآیند بیلد و تولید فایل نصبی J.A.R.V.I.S APK
echo ==========================================================

set KEYSTORE_FILE=my-upload-key.jks
set KEY_ALIAS=upload
set KEY_PASS=jarvis123456

REM ۱. ساخت کلید امضا در صورت عدم وجود
if not exist "%KEYSTORE_FILE%" (
    echo [1/3] در حال تولید Keystore برای نسخه Release...
    keytool -genkey -v -keystore "%KEYSTORE_FILE%" -alias "%KEY_ALIAS%" -keyalg RSA -keysize 2048 -validity 10000 -storepass "%KEY_PASS%" -keypass "%KEY_PASS%" -dname "CN=JARVIS, OU=AI, O=Stark, L=Tehran, ST=Tehran, C=IR"
    echo کلید اختصاصی با موفقیت ساخته شد: %KEYSTORE_FILE%
) else (
    echo [1/3] کلید Keystore از قبل موجود است.
)

REM ۲. تنظیم متغیرهای محیطی
set KEYSTORE_PATH=%cd%\%KEYSTORE_FILE%
set STORE_PASSWORD=%KEY_PASS%
set KEY_PASSWORD=%KEY_PASS%

REM ۳. اجرای بیلد گریدل
echo [2/3] در حال کامپایل و ساخت APK...
call gradle :app:assembleRelease
call gradle :app:assembleDebug

echo ==========================================================
echo  فرآیند ساخت با موفقیت به پایان رسید!
echo مسیر فایل‌های خروجی:
echo 1. نسخه Release: app\build\outputs\apk\release\app-release.apk
echo 2. نسخه Debug:   app\build\outputs\apk\debug\app-debug.apk
echo ==========================================================
pause
