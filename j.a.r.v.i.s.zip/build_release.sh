#!/bin/bash
# ==============================================================================
# اسکریپت ساخت فایل نصبی APK برای پروژه J.A.R.V.I.S
# ==============================================================================

set -e

echo "=========================================================="
echo "   شروع فرآیند بیلد و تولید فایل نصبی J.A.R.V.I.S APK"
echo "=========================================================="

KEYSTORE_FILE="my-upload-key.jks"
KEY_ALIAS="upload"
KEY_PASS="jarvis123456"

# ۱. ساخت کلید امضا در صورت عدم وجود
if [ ! -f "$KEYSTORE_FILE" ]; then
    echo "[۱/۳] در حال تولید Keystore برای نسخه Release..."
    keytool -genkey -v -keystore "$KEYSTORE_FILE" \
        -alias "$KEY_ALIAS" \
        -keyalg RSA -keysize 2048 -validity 10000 \
        -storepass "$KEY_PASS" -keypass "$KEY_PASS" \
        -dname "CN=JARVIS, OU=AI, O=Stark, L=Tehran, ST=Tehran, C=IR"
    echo "✓ کلید اختصاصی با موفقیت ساخته شد: $KEYSTORE_FILE"
else
    echo "[۱/۳] کلید Keystore از قبل موجود است."
fi

# ۲. تنظیم متغیرهای محیطی برای گریدل
export KEYSTORE_PATH="$(pwd)/$KEYSTORE_FILE"
export STORE_PASSWORD="$KEY_PASS"
export KEY_PASSWORD="$KEY_PASS"

# ۳. اجرای کامپایل نسخه Release و Debug
echo "[۲/۳] در حال کامپایل و بیلد فایل‌های APK..."
if command -v gradle &> /dev/null; then
    gradle :app:assembleRelease
    gradle :app:assembleDebug
elif [ -f "./gradlew" ]; then
    chmod +x ./gradlew
    ./gradlew :app:assembleRelease
    ./gradlew :app:assembleDebug
else
    echo "خطا: ابزار gradle یافت نشد. لطفاً Gradle یا Android Studio را نصب کنید."
    exit 1
fi

echo "=========================================================="
echo "✓ فرآیند ساخت با موفقیت به پایان رسید!"
echo "مسیر فایل‌های خروجی:"
echo "۱. نسخه Release امضا شده:"
echo "   app/build/outputs/apk/release/app-release.apk"
echo "۲. نسخه Debug (آماده تست فوری روی گوشی):"
echo "   app/build/outputs/apk/debug/app-debug.apk"
echo "=========================================================="
